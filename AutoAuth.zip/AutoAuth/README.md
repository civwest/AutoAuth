# Discord Bot

A Discord bot with OAuth2 account authorization, server member joining, and opt-in direct messages.

## Features

- `/adduser` — generates an OAuth2 authorization link for the person running the command.
- `/addmembers` — lets an administrator add previously authorized users to the server where authorization was requested.
- `/dmoptin` and `/dmoptout` — let members choose whether to receive bot direct messages.
- `/dmuser` — lets an administrator send a direct message to one opted-in user.
- `/dmall` — lets an administrator send a direct message to all opted-in users.
- SQLite storage for authorization records and DM preferences.
- Encrypted storage for OAuth access and refresh tokens.

## Requirements

- Node.js 20 or newer
- npm
- A Discord application and bot in the [Discord Developer Portal](https://discord.com/developers/applications)
- A public HTTPS web service for the OAuth callback (for example, Render)

## Project files

```text
your-project/
├── index.js
├── package.json
├── .env
├── .env.example
├── .gitignore
├── .npmrc
└── README.md
```

The SQLite database is created automatically when the bot runs. Do not commit it to source control.

## 1. Install dependencies on Windows

Open PowerShell and change directory to the folder that contains `package.json`. For example:

```powershell
cd "C:\path\to\your-project"
npm.cmd install
```

Use the actual path to your project folder. If PowerShell blocks `npm`, `npm.cmd` usually avoids the PowerShell script-policy issue.

## 2. Configure environment variables

Copy `.env.example` to `.env`, then fill in the values:

```dotenv
BOT_TOKEN=your_discord_bot_token
CLIENT_ID=your_discord_application_client_id
CLIENT_SECRET=your_discord_oauth_client_secret
REDIRECT_URI=https://your-service.onrender.com/oauth/callback
PORT=10000
STATE_SECRET=your_random_state_secret
TOKEN_ENCRYPTION_KEY=your_base64_32_byte_encryption_key
TEST_GUILD_ID=your_test_discord_server_id
```

Notes:

- `BOT_TOKEN`: token for the Discord bot user. Keep it secret.
- `CLIENT_ID`: Application ID from the Developer Portal.
- `CLIENT_SECRET`: OAuth2 client secret from the Developer Portal.
- `REDIRECT_URI`: must exactly match a redirect URL registered under **Developer Portal → OAuth2 → Redirects**.
- `PORT`: Render normally provides this automatically. If your code uses `process.env.PORT || 10000`, you can omit this variable on Render.
- `STATE_SECRET`: a strong random secret used to sign OAuth state values.
- `TOKEN_ENCRYPTION_KEY`: a randomly generated, base64-encoded 32-byte key used to encrypt stored OAuth tokens. Generate it once and preserve it; changing it makes existing encrypted tokens unreadable.
- `TEST_GUILD_ID`: the Discord server ID where development slash commands are registered.

Never share `.env`, bot tokens, OAuth client secrets, authorization codes, or stored access tokens. Do not commit `.env` to Git.

## 3. Configure the Discord application

In the Discord Developer Portal:

1. Open your application.
2. Under **OAuth2**, add the exact public callback URL, such as `https://your-service.onrender.com/oauth/callback`, to **Redirects**.
3. Make sure the OAuth flow requests the `identify` and `guilds.join` scopes.
4. Under **Bot**, copy the bot token into `BOT_TOKEN`.
5. Invite the bot to your test server with the permissions and application-command scope it needs.

The person authorizing must explicitly approve the OAuth consent screen. Opening the callback URL directly does not authorize an account.

## 4. Run locally

After the environment variables are configured:

```powershell
npm.cmd start
```

Keep the terminal open while testing. Use `/adduser` in your Discord server and click the authorization link returned by the bot. The callback URL must be reachable by Discord, so local testing requires a public HTTPS tunnel or a deployed HTTPS service.

## 5. Deploy to Render

1. Push the project to a private GitHub repository (without `.env` or the database).
2. Create a **Web Service** in Render and connect the repository.
3. Set the build command to `npm install`.
4. Set the start command to `npm start`.
5. Add the required environment variables in Render's **Environment** settings.
6. Use the Render service's public HTTPS URL for `REDIRECT_URI`, ending in `/oauth/callback`.
7. Add that exact callback URL in the Discord Developer Portal.

Do not hardcode your bot token or client secret in source code.

### Important note about persistent storage

If the bot uses a local SQLite file such as `bot-data.sqlite`, a free hosting instance with ephemeral storage may lose that database when the service restarts or redeploys. That can erase saved authorizations and DM preferences. For persistent use, configure a persistent disk supported by your host or move the database to a managed persistent database. Keep a backup before migrating or changing storage.

## Commands

| Command | Who can use it | Purpose |
|---|---|---|
| `/adduser` | Any member | Creates an OAuth2 authorization link for the member |
| `/addmembers` | Administrator | Adds authorized users to the server associated with the authorization |
| `/dmoptin` | Any member | Opts in to bot DMs |
| `/dmoptout` | Any member | Opts out of bot DMs |
| `/dmuser user message` | Administrator | Sends a DM to one opted-in user |
| `/dmall message` | Administrator | Sends a DM to opted-in users |

Exact command options may vary slightly depending on the version of `index.js` in the project.

## Troubleshooting

### The callback page opens but nothing happens

- Confirm you clicked **Authorize** on Discord's consent screen.
- Confirm `REDIRECT_URI` in Render and the Developer Portal are identical.
- Confirm the callback URL ends in `/oauth/callback`.
- Check Render's service logs immediately after testing.
- Use the authorization URL generated by `/adduser`; do not manually open the callback URL or construct a link without the signed `state` parameter.

### Slash commands do not appear

- Confirm `BOT_TOKEN`, `CLIENT_ID`, and `TEST_GUILD_ID` are correct.
- Confirm the bot is in the test server.
- Check Render logs or the local terminal for startup and command-registration errors.

### Member joining fails

- The target user must have authorized the `guilds.join` scope.
- The bot must be in the target server and have the required permissions.
- Check the Discord API error in the logs; do not repeatedly retry a failed request without understanding the error.

## Privacy and consent

Only message members who have opted in. Respect opt-outs promptly, identify the bot or server in messages, and follow Discord's Developer Terms, Developer Policy, and applicable privacy rules. Do not use OAuth authorization to add people to servers or message them without their informed consent.

## License

Add a license here if you intend to distribute this project. Until you choose one, all rights remain with the copyright holder.
